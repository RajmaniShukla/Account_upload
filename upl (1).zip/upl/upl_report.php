<html>
<body>
<link rel="stylesheet" href="upload_css.css">
<form name="e"  enctype="multipart/form-data">
<?php
ini_set('display_errors',0);
$tab = $_GET[val];
echo $tab;
?>
<p>
<div class="form-submit-btn">
<input type="button" value="Close Window" name = "sub" onclick="window.close()">
</div>
</body>
</form>