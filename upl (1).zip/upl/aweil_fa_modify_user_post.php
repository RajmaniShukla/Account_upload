<?php
session_start();
$sessid = session_id();
include_once('tennis_conn.php');
include_once('lib_func.php');
ini_set('display_errors',0);
extract($_POST);

 mysql_connect("$host:$port","$dbUser","$dbPassword") or die("Could not connect to the database!");
     mysql_select_db($database);
$_SESSION['usr_per'] = $user;


$stmt = "select count(*)cnt from m_user where user_per='$user' ";
$rs_rec = mysql_query ($stmt);
$r_rec = mysql_fetch_array($rs_rec);  
if (!$r_rec)
{
 
        echo '<script>alert("USER DOESNOT EXIST...Create User First");</script>';
        echo '<script>window.location.assign("aweil_fa_login.php");</script>';
       exit;
  
}

if ($new_pass != $re_pass) 
{
        echo '<script>alert("Password-Retype Passwords Mismatch ...Exiting");</script>';
        echo '<script>window.location.assign("aweil_fa_modify_user.php");</script>';
       exit;
}

$stmt = "select * from m_user where user_per='$user' and user_passwd='$pass'";
$rs_rec = mysql_query ($stmt);
$r_rec = mysql_fetch_array($rs_rec);  
if ($pass != $r_rec[user_passwd])
{
        echo '<script>alert("Invalid OLD Password ...Exiting");</script>';
        echo '<script>window.location.assign("aweil_fa_modify_user.php");</script>';
       exit;
}

	$upd_stmt = "update m_user set user_passwd = '$new_pass' where user_per = '$user' and user_passwd ='$pass' ";
    $ins_stmt = mysql_query($upd_stmt); 
    	session_destroy();
	session_unset();
	echo '<script>alert("ACCOUNT PASSWORD Modified SUCCESSFULLY");</script>';
        echo '<script>window.location.assign("aweil_fa_login.php");</script>';



?>
