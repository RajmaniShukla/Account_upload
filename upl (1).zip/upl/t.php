<?php

exec ("notepad.exe"); 
?>