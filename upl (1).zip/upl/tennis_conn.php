<?php
global $dbUser, $dbPassword, $database, $host, $port, $fy_name;
$dbUser="root";
$dbPassword="";
$database="tennis";
$host="127.0.0.1";
$port="3306";
$fy_name= "RFI"; 
?>