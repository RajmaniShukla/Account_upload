<?php
session_start();
if (! $_SESSION["IN_SESSION"]) {
	header("Location: aweil_fa_login.php");
        exit;
      }
    ini_set('display_errors',0);
include_once('tennis_conn.php');
mysql_connect("$host:$port","$dbUser","$dbPassword") or die("Could not connect to the database!");
mysql_select_db($database);
$user = $_SESSION['usr_per'];
 ?>
<?php
ini_set('display_errors',0);
include("tennis_conn.php");
$val = $_GET[nam];
$arr = explode("|",$val);
$url = "audit_files/";	
mysql_connect("$host:$port","$dbUser","$dbPassword") or die("Could not connect to the database!");
  mysql_select_db($database);

$tab= "<table class=\"tab\">";
$tab.="<tr><th  width=100% align='center'> Following Files Are Deleted from System</th></tr>";
for ($i=0;$i<count($arr);$i++)
{
  
$url1 = $url.$arr[$i];
	unlink($url1);
  $del_stmt = "delete from m_upload where f_name = '".$arr[$i]."'";

  $del_stmt = mysql_query($del_stmt); 
	$tab.='<tr><td>'.$arr[$i].'</td></tr>';
}
$tab.= '</table>';
echo $tab;
?>